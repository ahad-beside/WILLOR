<div id="footer" align="center" class="normal">
  <p></p>
    
  <p>- Copyright © 2019. All rights reserved. Willor Trust (New Zealand) Inc. -</p>
</div>