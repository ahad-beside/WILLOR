
<div id="admin-sidemenu"><!-- DivTable.com -->
  <table width="100%" border="0" bordercolor="" cellpadding="0" cellspacing="0">
  <tbody>
    <tr>
      <td bgcolor="#0200FF"><table width="100%" border="0" class="maimlogotable">
        <tbody>
          <tr>
            <td height="152" align="center" valign="middle"><img src="../images/wt-logo2.png" width="85" height="74" alt=""/><strong><span class="news"><br>
              </span><span class="willor">WILLOR TRUST</span></strong></td>
            </tr>
        </tbody>
      </table></td>
    </tr >
    <tr>
      <td height="40" align="center" bgcolor="#FFCD04" class="normal">ADMIN PANEL</td>
    </tr>
    <tr>
      <td height="90" align="center" bgcolor="#0000E0" class="news"><a href="../admin/index.php"><img src="../images/dasgboard.png" width="29" height="28" alt=""/><br>
        DASHBOARD</a></td>
      </tr>
    <tr>
      <td height="90" align="center" bgcolor="#0100F3" class="news"><a href="../admin/user.php"><img src="../images/acounticon.png" width="29" height="28" alt=""/><br>
        USER ACCOUNT</a></td>
      </tr>
    <tr>
      <td height="90" align="center" bgcolor="#0000E0" class="news"><a href="../admin/credit-acount.php"><img src="../images/deposit.png" width="29" height="28" alt=""/><br>
        DEPOSIT FUND</a></td>
      </tr>
    <tr>
      <td height="40" align="center" bgcolor="#FFCD04" class="normal">TRANSACTIONS</td>
    </tr>
    <tr>
      <td height="78" align="center" bgcolor="#0200FF" class="news"><a href="../admin/transfers.php"><br>
        <img src="../images/transfer-icon.png" width="29" height="28" alt=""/><br>
TRANSFER<br>
</a><br>
View Transfer | Edit Transfers </td>
    </tr>
    <tr>
      <td align="center" bgcolor="#0200FF" class="news"><p>&nbsp;</p></td>
    </tr>
    </tbody>
</table>


</div>
