
<div id="admin-header">
<table width="100%" border="0" class="topbar" cellpadding="5">
  <tbody>
    <tr>
      <td width="41%" height="46" bgcolor="#FFCE00">WILLOR TRUST LIMITED , <em class="special-button">We do things differently</em></td>
      <td width="7%" align="left" bgcolor="#0200ff" >  <span class="news" style="margin-left:5px"> News :</span></td>
      <td width="45%" bgcolor="#FFCE00">
      <marquee behavior="scroll" direction="left" scrollamount="2" class="normal" onmouseover="this.stop();" onmouseout="this.start();">
Welcome to Willor Trust e-Account for any enquiry call : +1 340 330 494 55.
      </marquee>
      </td>
      <td width="7%" bgcolor="#FFCE00" ><a href="logout.php" style="text-decoration:none" class="special-button-red">Logout</a></td>
    </tr>
  </tbody>
</table> 
<!--<div id="logo">
  <img src="images/wt-logo.png" width="150" height="107" alt="" style="margin-top:10px;"/> </div>-->

<!-- side menu begins -->
</div>
