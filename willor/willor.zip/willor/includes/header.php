
<div id="admin-header">
<table width="100%" border="0" class="topbar" cellpadding="5">
  <tbody>
    <tr>
      <td width="38%" height="46" align="center" bgcolor="#FFCE00"> <em class="special-button">- We do things differently -</em></td>
      <td width="8%" align="left" bgcolor="#2807FF" >  <span class="news" style="margin-left:5px"> News :</span></td>
      <td width="41%" bgcolor="#FFCE00">
      
     <marquee behavior="scroll" direction="left" scrollamount="3" class="normal" onmouseover="this.stop();" onmouseout="this.start();"><span class="warning">Ensure no one is looking over your shoulders as you use your card. Make sure you observe your surroundings. </span>|<span class="special-button"> Your Account User ID and Password are confidential. Do not disclose them to anyone.</span> | <span class="register">Always log on to our internet banking service via our website - www.willortrust.com </span>
        </marquee></td>
      <td width="13%" align="center" bgcolor="#FFCE00" ><a href="logout.php" style="text-decoration:none" class="special-button-red">- Logout -</a></td>
    </tr>
  </tbody>
</table> 
<!--<div id="logo">
  <img src="images/wt-logo.png" width="150" height="107" alt="" style="margin-top:10px;"/> </div>-->

<!-- side menu begins -->
</div>
