
<div id="admin-sidemenu"><!-- DivTable.com -->
  <table width="100%" border="0" bordercolor="" cellpadding="0" cellspacing="0">
  <tbody>
    <tr>
      <td bgcolor="#0200FF"><table width="100%" border="0" class="maimlogotable">
        <tbody>
          <tr>
            <td height="152" align="center" valign="middle"><img src="https://willortrust.com/willor/images/wt-logo2.png" width="88" height="76" alt=""/><strong><span class="news"><br>
              </span><span class="willor">WILLOR TRUST</span></strong></td>
            </tr>
        </tbody>
      </table></td>
    </tr >
    <tr>
      <td height="50" align="center" bgcolor="#FFCD04" class="normal"><strong>ACCOUNT</strong></td>
    </tr>
    <tr>
      <td height="50" align="center" bgcolor="#0000E0" class="news"><a href="../willor/index.php"><br>
        SUMMARY </a></td>
      </tr>
    <tr>
      <td height="50" align="center" bgcolor="#0100F3" class="news"><a href="../willor/account-details.php"><br>
        ACCOUNT DETAILS</a></td>
      </tr>
    <tr>
      <td height="50" align="center" bgcolor="#0000E0" class="news"><a href="../willor/account-statement.php"><br>
        ACCOUNT STATEMENT</a></td>
      </tr>
    <tr>
      <td height="50" align="center" bgcolor="#0100F3" class="news"><a href="../willor/local-transfer.php">LOCAL TRANSFER</a></td>
    </tr>
    <tr>
      <td height="50" align="center" bgcolor="#0000E0" class="news"><a href="../willor/international-transfer.php">INTERNATIONAL TRNASFER</a></td>
    </tr>
    <tr>
      <td height="50" align="center" bgcolor="#0100F3" class="news"><a href="../willor/contact-us.php"><br>
        CONTACT US</a></td>
      </tr>
    <tr>
      <td height="50" align="center" bgcolor="#FFCD04" class="normal"><strong>SECURITY SETTING</strong></td>
    </tr>
    <tr>
      <td height="50" align="center" bgcolor="#0200FF" class="news"><a href="../willor/user-profile.php">USER PROFILE</a></td>
    </tr>
    <tr>
      <td height="50" align="center" bgcolor="#0000E0" class="news"><a href="../willor/change-password.php">CHANGE PASSWORD</a></td>
    </tr>
    <tr>
      <td height="50" align="center" bgcolor="#0200FF" class="news"><p><a href="../willor/change-pin.php">CHANGE PIN</a></p></td>
    </tr>
    </tbody>
</table>


</div>
