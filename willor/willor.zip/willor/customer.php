
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Willor Trust Limited</title>
<link href="css/style.css" rel="stylesheet" type="text/css"/>
<link href="css/divstyle.css" rel="stylesheet" type="text/css"/>

<link href="https://fonts.googleapis.com/css?family=Roboto&display=swap" rel="stylesheet">
<script type="text/javascript">
function MM_openBrWindow(theURL,winName,features) { //v2.0
  window.open(theURL,winName,features);
}
</script>
</head>
<style type="text/css">
body {
margin-left:0px;
margin-bottom:0px;
margin-right:0px;
margin-top:0px;
background-color:;

}

</style>

<body>


<div id="container">
<div id="header">
<table width="100%" border="0" class="topbar" cellpadding="5">
  <tbody>
    <tr>
      <td width="56%" height="46" bgcolor="#FFCE00"><a class="normal" style="margin-left:20px">Policies   |  Complains  |   Application Form |  FAQs</a></td>
      <td width="9%" align="left" bgcolor="#0200ff" ><a href="logout.php"><span class="news" style="text-decoration:none">Logout</span></a></td>
      <td width="35%" bgcolor="#FFCE00">
      <marquee behavior="scroll" direction="left" scrollamount="2" class="normal" onmouseover="this.stop();" onmouseout="this.start();">
Welcome to Willor Trust e-Account for any enquiry call : +1 340 330 494 55
      </marquee>
      </td>
    </tr>
  </tbody>
</table> 
<!--<div id="logo">
  <img src="images/wt-logo.png" width="150" height="107" alt="" style="margin-top:10px;"/> </div>-->

<!-- side menu begins -->
</div>
<div id="sidemenu">
<div class="divTable" style="width: 100%;border:0px;" >
<div class="divTableBody">
<div class="divTableRow">

<!-- fixing logo and name -->
<div class="divTableCell" >
  <table width="100%" border="0" class="maimlogotable">
    <tbody>
      <tr >
        <td width="33%" height="117"><img src="images/wt-logo2.png" style="padding:5px;" width="109" height="95" alt=""/></td>
        <td width="67%"><span class="logo-name">WILLOR TRUST<br>
LIMITED</span></td>
      </tr>
    </tbody>
</table>
</div>
</div>
<div class="divTableRow">
<div class="divTableCell" ><img src="images/TYPE2.png" width="442" height="306" alt=""/></div>
</div>
<div class="divTableRow">
<div class="divTableCell">
<div class="topbar" style="color:#fff" >
<table width="100%" border="0">
  <tbody>
    <tr>
      <td width="17%"><img src="images/key.png" width="55" height="57" alt=""/></td>
      <td width="83%"><strong  >You're logging into a secure site</strong><br>
 How can I tell that this <br>
site is secure?</td>

    </tr>
  </tbody>
</table>
 </div>
 <div class="divTableRow" ><hr width="80%"  style="border-color:#FFF">
   <blockquote>
     <p class=" news" style=" text-align:justify;"><br>
       
       <strong style="font-size:16px;">Willor Trust e-Account</strong><br>
       Willor Trust uses secure accress, which has two step login mechanism to make your online banking even safer.
       <p class=" news" style=" text-align:justify;">
       A personalised picture and message will help you autenticate our website; meanwhile and mutilayer autentication proccess requires registration for any third party transaction.</p>
       <p class="notes" style=" text-align:justify;">
       <strong>Note:</strong> Willor Trust will never send you a link to your email to access your account.</p>
     </p>
   </blockquote>
 </div>
</div>
</div>
</div>
</div>
<!-- DivTable.com -->
</div>
<!--- sidemenu ended -->
<div id="banner" style="background-image:url(images/banner.png)"> </div>
<div id="mainbody">
<table width="100%" border="0">
  <tbody>
    <tr>
      <td colspan="3"> <blockquote>
        <p><span class="welcome">Welcome to e-Account. </span><span class="login">Login</span><br>
          <span class="normal"><br>
          If you don't already use Willor Trust e-Account, it's simple, </span>
          
          
          
          <span class="register" ><a href="register.php" class="special-button" style="text-decoration:none;">Click to Register</a></span></p>
      </blockquote></td>
    </tr>
    <tr>
      <td colspan="3"><blockquote>
        <table width="70%%" border="0" align="left" cellpadding="20" cellspacing="5">
          <tbody>
            <tr bgcolor="#EDEDED">
              <!-- main login form is here -->
              <td height="175" bgcolor="#FFF6D2">
            <form action="" method="post">
            <table width="100%" border="0">
  <tbody>
    <tr>
      <td width="12%" align="center" style="margin-right:5px;"><img src="images/accno.png" width="35" height="34" alt=""/></td>
      <td width="29%" class="passacc">Account Number :</td>
      <td width="59%"><input name="accountno" type="text" required class="input" id="accountno"></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td align="center" style="margin-right:5px;"><img src="images/passx.png" width="35" height="34" alt=""/></td>
      <td class="passacc">Password:</td>
      <td><input name="password" type="password" required class="input" id="password"></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <?php echo isset($error)?$error:''; ?>
      <td><input name="submit" type="submit" class="button" id="submit" value="Continue"></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td colspan="2" align="right" class="register">&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td colspan="2" align="right" class="register">Forgotten your logon details? Click Here</td>
    </tr>
  </tbody>
</table>

            </form>
              </td>
            </tr>
          </tbody>
        </table>
        <p>&nbsp;</p>
      </blockquote></td>
    </tr>
    <tr>
      <td colspan="3">&nbsp;</td>
      </tr>
    <tr>
      <td width="5%" bgcolor="#FFFFFF">&nbsp;</td>
      <td width="6%" valign="top" bgcolor="#FFFFFF"><img src="images/orange-button.png" width="33" height="43" alt=""/></td>
      <td width="89%" bgcolor="#FFFFFF"><p><span class="shoppingonline">Shopping and banking online is changing</span><br>
        <span class="normal">Soon, all banks will be carrying out extra security checks to make sure it’s really you when you’re shopping and banking online. To make it easier, please make sure we have your up-to-date contact number. Find out more now.</span></p>
        <p>&nbsp;</p></td>
    </tr>
    <tr>
      <td height="32" colspan="3" align="right" bgcolor="#e6e7e8" class="normal" style="margin-left:5px; margin-right:5px; text-align: center;"> Copyright ©  2019. All rights reserved. Willor Trust (New Zealand) Inc.</td>
    </tr>
  </tbody>
</table>


</div>

<div id="mainfooter"></div>
<div id="sidecontent"></div>
</div>
</body>
</html>
