<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>
<?php include 'includes/footer.php';?>
<body>
</body>
</html>